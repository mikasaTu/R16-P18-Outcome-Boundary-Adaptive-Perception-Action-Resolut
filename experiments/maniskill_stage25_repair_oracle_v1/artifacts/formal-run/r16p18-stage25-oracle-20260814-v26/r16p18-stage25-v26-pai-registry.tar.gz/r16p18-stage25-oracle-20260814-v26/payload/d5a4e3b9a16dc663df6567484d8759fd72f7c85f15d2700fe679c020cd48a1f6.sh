#!/usr/bin/env bash
set -euo pipefail

umask 077

if [[ "$(id -u)" != "2254" || "$(id -g)" != "2254" ]]; then
  echo "runtime identity must remain 2254:2254" >&2
  exit 73
fi

readonly source_root="/mnt/cpfs/zbl-cpfs-new/USERS/leon/code/R16-P18-Outcome-Boundary-Adaptive-Perception-Action-Resolut-stage25-formal-source"
readonly experiment_root="${source_root}/experiments/maniskill_stage25_repair_oracle_v1"
readonly frozen_launcher="${experiment_root}/launchers/run_stage25_pai.sh"
readonly expected_frozen_launcher_sha256="678db2b187d6ac32b8b34e2b60ff3ae0b43eee28b25ce7daa5c5f75e49742204"
readonly expected_scientific_sums_sha256="8a606d77d2e70ca6147943c01ba1dc7a8f713852f486698b7998c50c364b5e4f"
readonly run_id="${PAI_CANARY_RUN_ID:?PAI_CANARY_RUN_ID is required}"
readonly result_root="/mnt/cpfs/zbl-cpfs-new/CKPT/leon/torch/r16-p18-maniskill-stage25-repair-oracle-v1/${run_id}"
readonly gpu_count="${PAI_CANARY_EXPECTED_GPUS:?PAI_CANARY_EXPECTED_GPUS is required}"
readonly artifact_dir="${PAI_CANARY_RUN_DIR:?PAI_CANARY_RUN_DIR is required}"
readonly runtime_python="/mnt/cpfs/zbl-cpfs-new/USERS/leon/envs/libero_sft/bin/python"
readonly overlay="/mnt/cpfs/zbl-cpfs-new/USERS/leon/envs/r16p18-maniskill-act-v301-overlay/site-packages"
readonly maniskill_root="/mnt/cpfs/zbl-cpfs-new/USERS/leon/code/ManiSkill-r16p18-v3.0.1"
readonly old_data="/mnt/cpfs/zbl-cpfs-new/dataset/leon/r16-p18-maniskill-act-boundary-screen-v1"
readonly atlas_smoke_output="${artifact_dir}/CUDA_ACTION_ATLAS_SMOKE.json"
readonly atlas_smoke_reference_root="/mnt/cpfs/zbl-cpfs-new/CKPT/leon/torch/r16-p18-maniskill-stage25-repair-oracle-v1/r16p18-stage25-oracle-20260814-v17"
readonly atlas_smoke_selection="${atlas_smoke_reference_root}/checkpoint/final_selection.json"
readonly atlas_smoke_state_manifest="${atlas_smoke_reference_root}/state_banks/calibration/state_bank_manifest.json"

exec > >(tee -a "${artifact_dir}/runtime.log") 2>&1
preflight_stage="entry"
trap 'rc=$?; printf "OPERATIONAL_PREFLIGHT_FAILED stage=%s rc=%s\n" "${preflight_stage}" "${rc}"; exit "${rc}"' ERR

preflight_stage="required_commands"
for required in git sha256sum nvidia-smi realpath stat tee sync; do
  command -v "${required}" >/dev/null
done
preflight_stage="run_and_gpu_contract"
[[ "${run_id}" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{2,63}$ ]]
test "${gpu_count}" = "2"
preflight_stage="source_git_binding"
test "$(realpath -e "${source_root}")" = "${source_root}"
test "$(git -C "${source_root}" rev-parse HEAD)" = "7be99cd867d27372cfc75095d459b782c0f75a66"
test "$(git -C "${source_root}" rev-parse 'HEAD^{tree}')" = "31df45e1f28bbba57aebcd804e13c88fe14a0784"
test -z "$(git -C "${source_root}" status --porcelain)"
preflight_stage="scientific_hash_binding"
test "$(sha256sum "${frozen_launcher}" | awk '{print $1}')" = "${expected_frozen_launcher_sha256}"
test "$(sha256sum "${experiment_root}/PROTOCOL_FREEZE.json" | awk '{print $1}')" = "9fd66b86e3d8176baa65da783ee5e3f41df5b1d86a841fa4535e52cd9991c7ca"
test "$(sha256sum "${experiment_root}/manifests/SCIENTIFIC_SHA256SUMS" | awk '{print $1}')" = "${expected_scientific_sums_sha256}"
(
  cd "${experiment_root}"
  sha256sum -c manifests/SCIENTIFIC_SHA256SUMS >/dev/null
)
preflight_stage="cuda_smoke_reference_binding"
test "$(sha256sum "${atlas_smoke_selection}" | awk '{print $1}')" = "efd079374bf22fd4de1f7aada7c9da1191c6a52807bd6bcb6bfe71647d93e34f"
test "$(sha256sum "${atlas_smoke_state_manifest}" | awk '{print $1}')" = "f231e58b326b77982c963f58750a3d0cb39c8b77847b784e46ddf50fa90bb9b3"
test "$(sha256sum "${atlas_smoke_reference_root}/state_banks/calibration/state_bank.h5" | awk '{print $1}')" = "f148cf6b32ebe3f1a9ea7f10e71b7ec5259edeee65e10fe6116065703f476649"
preflight_stage="gpu_inventory"
test "$(nvidia-smi --query-gpu=name --format=csv,noheader | grep -c '^NVIDIA A800')" = "${gpu_count}"
preflight_stage="write_path_contract"
case "${result_root}" in
  /mnt/cpfs/zbl-cpfs-new/CKPT/leon/torch/r16-p18-maniskill-stage25-repair-oracle-v1/*) ;;
  *) echo "result root escaped the frozen experiment root" >&2; exit 71 ;;
esac
case "${artifact_dir}" in
  /mnt/cpfs/zbl-cpfs-new/USERS/leon/logs/r16-p18-maniskill-stage25-repair-oracle-v1/pai/*) ;;
  *) echo "artifact root escaped the frozen PAI log root" >&2; exit 72 ;;
esac

export PYTHONPATH="${source_root}:${maniskill_root}/examples/baselines/act:${maniskill_root}:${overlay}"
export WANDB_MODE=disabled
export WANDB_DISABLED=true
export PYTHONUNBUFFERED=1

preflight_stage="result_root_owner"
mkdir -p "${result_root}"
test "$(stat -c '%u:%g' "${result_root}")" = "2254:2254"
preflight_stage="safe_workdir"
cd "${artifact_dir}"
test "$(pwd -P)" = "${artifact_dir}"
preflight_stage="cuda_action_atlas_smoke"
test ! -e "${atlas_smoke_output}"
CUDA_VISIBLE_DEVICES=0 "${runtime_python}" \
  "${experiment_root}/scripts/smoke_action_atlas_cuda.py" \
  --selected-checkpoints "${atlas_smoke_selection}" \
  --state-bank-manifest "${atlas_smoke_state_manifest}" \
  --training-h5 "${old_data}/selected_raw/StackCube-v1/train/trajectory.rgb.pd_ee_delta_pos.physx_cpu.h5" \
  --output "${atlas_smoke_output}"
"${runtime_python}" -c \
  'import json, pathlib, sys; value=json.loads(pathlib.Path(sys.argv[1]).read_text()); assert value["status"] == "CUDA_ACTION_ATLAS_SMOKE_PASS" and value["scientific_evidence"] is False and value["candidate_validity"] >= 0.90 and value["non_null_outcomes"] > 0' \
  "${atlas_smoke_output}"
sync "${atlas_smoke_output}"
trap - ERR

child_pid=""
handle_signal() {
  printf '{"protocol_id":"R16-P18-MS4-STAGE25-REPAIR-ORACLE-V1","status":"PREEMPTION_SIGNAL_RECEIVED","run_id":"%s"}\n' "${run_id}" > "${result_root}/PREEMPTION_SIGNAL.json"
  sync "${result_root}"
  if [[ -n "${child_pid}" ]]; then
    kill -TERM "${child_pid}" 2>/dev/null || true
    wait "${child_pid}" || true
  fi
  exit 99
}
trap handle_signal TERM INT

"${runtime_python}" "${experiment_root}/scripts/run_stage25_formal.py" \
  --run-id "${run_id}" \
  --result-root "${result_root}" \
  --candidate-manifest "${experiment_root}/manifests/checkpoint_candidates.json" \
  --screen-seed-bank "${experiment_root}/manifests/checkpoint_screen_seed_bank.json" \
  --final-val-seed-bank "${experiment_root}/manifests/checkpoint_final_val_seed_bank.json" \
  --confirmatory-seed-bank "${experiment_root}/manifests/confirmatory_test_seed_bank.json" \
  --oracle-seed-bank "${experiment_root}/manifests/oracle_source_seed_bank.json" \
  --official-stack-h5 "${old_data}/official_demos/StackCube-v1/motionplanning/trajectory.h5" \
  --training-stack-h5 "${old_data}/selected_raw/StackCube-v1/train/trajectory.rgb.pd_ee_delta_pos.physx_cpu.h5" \
  --gpu-count "${gpu_count}" &
child_pid="$!"
wait "${child_pid}"
